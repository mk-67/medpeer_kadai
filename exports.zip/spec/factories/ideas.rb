FactoryBot.define do
  factory :idea do
    
  end
end
