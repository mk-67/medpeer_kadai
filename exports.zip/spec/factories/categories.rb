FactoryBot.define do
  factory :category do
    
  end
end
